Practice data for the "SQL for Python Developers" series at jamalhansen.com

customers.csv  500 customers (id, name, email, city, signup_date, is_premium)
orders.csv     1,000 orders  (id, customer_id, product, amount, order_date)
generate_practice_data.py   the script that made them (pip install faker)

Load into DuckDB:
    import duckdb
    con = duckdb.connect("practice.duckdb")
    con.execute("CREATE TABLE customers AS SELECT * FROM read_csv_auto('customers.csv')")
    con.execute("CREATE TABLE orders AS SELECT * FROM read_csv_auto('orders.csv')")
