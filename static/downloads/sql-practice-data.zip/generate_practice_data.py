"""Generate the practice data used in the SQL for Python Developers series.

Same code as posts 03 and 12, same seed, so you get the same rows the posts show.
    pip install faker
    python generate_practice_data.py        # writes customers.csv and orders.csv
"""

import csv
import random
from datetime import date

from faker import Faker

fake = Faker()
Faker.seed(42)
random.seed(42)

customers = []
for i in range(500):
    customers.append(
        {
            "id": i + 1,
            "name": fake.name(),
            "email": fake.email(),
            "city": fake.city(),
            "signup_date": fake.date_between(start_date=date(2024, 1, 1), end_date=date(2025, 12, 31)),
            "is_premium": random.choice([True, False, False, False]),
        }
    )

Faker.seed(42)
random.seed(42)
products = ["Widget", "Gadget", "Gizmo", "Thingamajig", "Doohickey"]
orders = []
for i in range(1000):
    orders.append(
        {
            "id": i + 1,
            "customer_id": random.randint(1, 500),
            "product": random.choice(products),
            "amount": round(random.uniform(10, 500), 2),
            "order_date": fake.date_between(start_date=date(2025, 1, 1), end_date=date(2025, 12, 31)),
        }
    )

for name, rows in (("customers.csv", customers), ("orders.csv", orders)):
    with open(name, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"wrote {name}: {len(rows)} rows")

# Load them into DuckDB like this:
#   import duckdb
#   con = duckdb.connect("practice.duckdb")
#   con.execute("CREATE TABLE customers AS SELECT * FROM read_csv_auto('customers.csv')")
#   con.execute("CREATE TABLE orders AS SELECT * FROM read_csv_auto('orders.csv')")
